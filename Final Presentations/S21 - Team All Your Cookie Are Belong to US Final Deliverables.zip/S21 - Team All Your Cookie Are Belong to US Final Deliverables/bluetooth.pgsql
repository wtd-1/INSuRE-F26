\connect apple_iphone

CREATE TABLE public.Advertisment (
	deviceid int NOT NULL,
    	capture_starttime bigint,
	capture_endtime bigint, 
	Advertising_Packet_Frequency double precision,
	Average_Packet_Length double precision,
	percentage_adv_ind double precision,
	percentage_adv_nonconn_ind double precision,
	percentage_adv_direct_ind double precision,
	percentage_adv_scan_ind double precision,
	num_mac_addresses int
	

);

CREATE TABLE public.Data (
        deviceid int NOT NULL,
        capture_starttime bigint,
        capture_endtime bigint


);




