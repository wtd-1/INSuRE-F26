from __future__ import division
import sys
import psycopg2
import datetime
from scapy.all import *

#This script finds all the features listed in our report and inserts them into a database

def calculateAdvInt(pcapFile, device):
   
    starttime = 0
    enddtime = 0
    deviceId = ""
    databaseName = ""
    if device == "Apple":
        deviceId = "0x4c" 
        databaseName = "apple_iphone"

    elif device == "Samsung":
        deviceId = "0x75"
        databaseName = "samsung_galaxy_watch"

    con = psycopg2.connect(database=databaseName, user="username", password="", port="5432")
    cur = con.cursor()

    listOfAddr = []

    avgPktLength = 0
    lenPkts = []

    #calculate % of each advertising packets
    numAdvInd = 0
    numAdvNonconn = 0
    numAdvDirect = 0
    numAdvScan = 0
    other = 0

    captureHour = 0
    startCaptureHour = False

    #manufacturer
    manu = ""

    #store time intervals
    advIntervals = []
    #flag to take care of first time stamp
    firstTime = True
    #keeps track of previous timestamp
    startIntervalTime = 0

    #read packets from pcap file
    pkts = rdpcap(pcapFile)

    #iterate over packets
    for pkt in pkts:

        #set hour intervals
        if not startCaptureHour:
            startCaptureHour = True
            captureHour = int(pkt.time) + 60 * 60 * 1000
            print("Starting packet time: " + str(int(pkt.time)))
            starttime = int(pkt.time)

        #if we're done analyzing the hour, reset the capture hour and calculate the average time interval 
        #<a:think360:393855331857334282>

        if int(pkt.time) > captureHour:
            if len(listOfAddr) > 0:
                apf = calculateAvgTimeInterval(advIntervals)
                numAdvInd, numAdvNonconn, numAdvDirect, numAdvScan = calculatePercentageAdv(numAdvInd, numAdvNonconn, numAdvDirect, numAdvScan, other)
                apl = 0
                if len(lenPkts) != 0:
                    print("Average packet length: " + str((avgPktLength)/ len(lenPkts)))
                    apl = avgPktLength/ len(lenPkts)

                print("Num MAC Addresses: "  + str(len(listOfAddr)))
                nma = len(listOfAddr)

                print("Ending packet time: " + str(int(pkt.time)))
                print("Starting packet time: " + str(int(pkt.time)))
                sqlCommand = "({0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9})".format(int(deviceId, 16), starttime, int(pkt.time), apf, apl, numAdvInd, numAdvNonconn, numAdvDirect, numAdvScan, nma)
                sqlCommand= "INSERT INTO  advertisment (deviceid, capture_starttime, capture_endtime, advertising_packet_frequency, average_packet_length, percentage_adv_ind, percentage_adv_nonconn_ind, percentage_adv_direct_ind, percentage_adv_scan_ind, num_mac_addresses) VALUES {0}".format(sqlCommand)

                print(sqlCommand)

                cur.execute(sqlCommand)
                con.commit()

            captureHour = int(pkt.time) + 60 * 60 * 1000
            starttime = int(pkt.time)
            listOfAddr = []

        #get string between 'PDU_type' string and 'unused' string in packet
        pduType = str(pkt.show).split("PDU_type",1)[1].split("unused")

        #remove = and new line from resulting string 
        pduType = pduType[0].replace("=", "").strip()

        #get apple or samsung packets
        if "company_id=" in str(pkt.show):
            manu = str(pkt.show).split("company_id=",1)[1].split("|")
            manu = manu[0].strip()

        #if the extracted PDU type indicated that the packet was an advertising packet, get the timesm=tamp of the packet
        if "ADV" in pduType and manu == deviceId:

            if pduType == "ADV_IND":
                numAdvInd += 1
            elif pduType == "ADV_NONCONN_IND":
                numAdvNonconn += 1
            elif pduType == "ADV_DIRECT_IND":
                numAdvDirect += 1
            elif pduType == "ADV_SCAN_IND":
                numAdvScan += 1
            else:
                other += 1

            #get address used
            addr = str(pkt.show).split("AdvA=",1)[1].split("Data")
            addr = addr[0].strip()

            #add to list if not already there
            if addr not in listOfAddr:
                listOfAddr.append(addr)

            avgPktLength = len(pkt) + avgPktLength
            lenPkts.append(len(pkt))

            #remove miliseconds
            time = int(pkt.time)/1000
            #convert unix timestamp to seconds
            timeSeconds = int(datetime.fromtimestamp(time).strftime('%S'))
            
            #print(timeSeconds) 
            
            #if we are at our first packet
            if firstTime:
                #start interval calculation
                firstTime = False
                startIntervalTime = timeSeconds
                continue

            #if the time (in seconds) extracted from the packet is less than the previous timestamp, add 60 (since we are in the next minute)
            if timeSeconds < startIntervalTime:
                timeSeconds += 60

            #calculate the interval between the current time and the previous time
            interval = timeSeconds - startIntervalTime
            

            #rest the previous time if we added 60 
            if timeSeconds > 60:
                timeSeconds -= 60

            #store the current time to calculate the next interval
            startIntervalTime = timeSeconds

            #add new interval to list
            advIntervals.append(interval)

    
    #return advIntervals
            
def calculatePercentageAdv(numAdvInd, numAdvNonconn, numAdvDirect, numAdvScan, other):
    total = numAdvInd + numAdvNonconn + numAdvDirect + numAdvScan + other

    if total == 0:
        return

    print("Percentage ADV_IND " + str((numAdvInd/total) * 100))
    print("Percentage ADV_NONCONN_IND " + str((numAdvNonconn/total) * 100))
    print("Percentage ADV_DIRECT_IND " + str((numAdvDirect/total) * 100))
    print("Percentage ADV_SCAN_IND " + str((numAdvScan/total)* 100))
    print("Percentage OTHER " + str((other/total)* 100))

    return (numAdvInd/total) * 100, (numAdvNonconn/total) * 100, (numAdvDirect/total) * 100, (numAdvScan/total)* 100

def calculateAvgTimeInterval(advIntervals):
    average = 0

    for time in advIntervals:
        average += time
    
    if len(advIntervals) == 0:
        return

    average = average/len(advIntervals)

    print("The average time interval between advertisment packets is " + str(average) + " seconds")

    return average

def main():

    #if the user doesn't supply pcap file, exit
    if(len(sys.argv) < 3 or len(sys.argv) > 3):
        print("USAGE: python advInt.py <pcap file> <Apple | Samsung>")
        exit(1)

    #get pcap file as cmd line arg
    pcapFile = sys.argv[1]

    device = sys.argv[2]

    calculateAdvInt(pcapFile, device)

    '''#calculate the intervals between the advertisment packets
    advIntervals = calculateAdvInt(pcapFile)

    print(advIntervals)

    #given the intervals, calculate the average time interval between advertisment packets
    calculateAvgTimeInterval(advIntervals)'''








main()

