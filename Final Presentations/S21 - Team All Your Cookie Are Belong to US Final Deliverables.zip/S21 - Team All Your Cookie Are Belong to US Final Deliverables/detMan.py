import sys
import datetime
from scapy.all import *


'''
SCRIPT THAT CHECKS FOR SAMSUNG WATCH ADVERTISING PACKETS
0x4c : Apple
0x6 Microsoft
HP: 0xfdf7
Samsung: 0x75
Google: 0xfe9f
'''

def detMan(pcap):

    #read packets from pcap file
    pkts = rdpcap(pcap)

    msft = 0
    sam = 0
    app = 0
    goo = 0
    hp = 0


    for pkt in pkts:
        #get string between 'PDU_type' string and 'unused' string in packet
        pduType = str(pkt.show).split("PDU_type",1)[1].split("unused")

        #remove = and new line from resulting string
        pduType = pduType[0].replace("=", "").strip()

        #for Microsoft, Apple, and Samsung
        if "ADV" in pduType and "company_id=" in str(pkt.show):
            manu = str(pkt.show).split("company_id=",1)[1].split("|")
            manu = manu[0].strip()
            #not MSFT or Apple
            '''if str(manu) != "0x6" and str(manu) != "0x4c":
                print(manu)
                print(str(pkt.show))'''

            #count number of each type of packet
            if manu == "0x6":
                msft+= 1
            elif manu == "0x4c":
                app+= 1
            elif manu == "0x75":
                sam+= 1

        #For Google and HP Packets
        elif  "ADV" in pduType and "uuid" in str(pkt.show):
            try:
                manu = str(pkt.show).split("svc_uuid=",1)[1].split("|")
                manu = manu[0].strip()
            
            
                if manu == "0xfdf7":
                    hp += 1
                elif manu == "0xfe9f":
                    goo += 1

            except IndexError:
                print("Malformed packet, skipping")
                pass


    print("Number of Microsoft Packets: " + str(msft))
    print("Number of Apple Packets: " + str(app))
    print("Number of Google Packets: " + str(goo))
    print("Number of HP Packets: " + str(hp))
    print("\033[1mNumber of Samsung Packets: " + str(sam))


        #manu = str(pkt.show).split("PDU_type",1)[1].split("unused")


def main():
    #if the user doesn't supply pcap file, exit
    if(len(sys.argv) < 2 or len(sys.argv) > 2):
        print("USAGE: python detMan.py <pcap file>")
        exit(1)

    #get pcap file as cmd line arg
    pcapFile = sys.argv[1]

    detMan(pcapFile)


main()
