--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: advertisment; Type: TABLE; Schema: public; Owner: vishalmadipadga
--

CREATE TABLE public.advertisment (
    deviceid integer NOT NULL,
    capture_starttime bigint,
    capture_endtime bigint,
    advertising_packet_frequency double precision,
    average_packet_length double precision,
    percentage_adv_ind double precision,
    percentage_adv_nonconn_ind double precision,
    num_mac_addresses integer
);


ALTER TABLE public.advertisment OWNER TO vishalmadipadga;

--
-- Name: data; Type: TABLE; Schema: public; Owner: vishalmadipadga
--

CREATE TABLE public.data (
    deviceid integer NOT NULL,
    capture_starttime bigint,
    capture_endtime bigint
);


ALTER TABLE public.data OWNER TO vishalmadipadga;

--
-- Data for Name: advertisment; Type: TABLE DATA; Schema: public; Owner: vishalmadipadga
--

COPY public.advertisment (deviceid, capture_starttime, capture_endtime, advertising_packet_frequency, average_packet_length, percentage_adv_ind, percentage_adv_nonconn_ind, num_mac_addresses) FROM stdin;
117	1619117401617	1619121097637	0.744055944056	43	100	0	1
117	1619121097637	1619124963104	0.75326058025	43	100	0	1
117	1619124963104	1619128633133	0.761081081081	43	100	0	1
117	1619128633133	1619132411374	0.754330879168	43	100	0	1
117	1619123876961	1619127669802	0.732584269663	43.0058400719	99.9550763702	0.0449236298293	2
117	1619127669802	1619131517041	0.733686067019	43.0028653295	99.9981367221	0.00186327788591	1
117	1619131517041	1619135117084	0.7482898227	43.0018146287	99.999931673	6.83270218522e-05	1
117	1619135117084	1619138854801	0.748677534276	43.0014032815	99.9999968942	3.10577372056e-06	1
117	1619138854801	1619142683889	0.7460776218	43.0010734043	99.9999998946	1.05387638974e-07	1
117	1619142683889	1619146549371	0.748938360571	43.0008363894	99.999999997	2.98379498793e-09	1
117	1619146549371	1619150226450	0.750954198473	43.0006891068	99.9999999999	8.71944765614e-11	1
117	1619150226450	1619153850822	0.752063323519	43.0006274131	100	4.46007552744e-12	1
117	1619115488413	1619119131430	0.795530726257	43.1042442293	98.5107967238	1.48920327625	2
117	1619137293853	1619140959443	0.753039513678	43	100	0	1
117	1619140959443	1619144869790	0.782335025381	43	100	0	1
117	1619144869790	1619148488466	0.797357482185	43	100	0	1
117	1619148488466	1619152317079	0.777810885975	43	100	0	1
\.


--
-- Data for Name: data; Type: TABLE DATA; Schema: public; Owner: vishalmadipadga
--

COPY public.data (deviceid, capture_starttime, capture_endtime) FROM stdin;
\.


--
-- PostgreSQL database dump complete
--

