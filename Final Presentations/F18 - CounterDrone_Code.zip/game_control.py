import pygame
import time
import subprocess

pygame.init()

joystick = pygame.joystick.Joystick(0)
joystick.init()

value = 0.0
while True:
	time.sleep(1)
	print(value)
	if value > 0.05:
		subprocess.call(["node", "takeoff.js"])
	elif value > 0.1:
		subprocess.call(["node", "landing.js"])

	pygame.event.pump()
	value = joystick.get_axis(0)