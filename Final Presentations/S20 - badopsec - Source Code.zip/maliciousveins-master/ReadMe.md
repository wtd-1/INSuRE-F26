Make sure to run configure and make before running the simulation.

Simulation is set up for a normal car simulation, not a DOS currently. 
