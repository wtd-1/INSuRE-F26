#pragma once

#include "maliciousveins/maliciousveins.h"

#include "veins/modules/application/ieee80211p/DemoBaseApplLayer.h"

namespace maliciousveins {

class MALICIOUSVEINS_API maliciousRSU : public veins::DemoBaseApplLayer {
        protected:
            void onWSM(veins::BaseFrame1609_4* wsm) override;
            void onWSA(veins::DemoServiceAdvertisment* wsa) override;
            void onBSM(veins::DemoSafetyMessage* bsm) override;
    };
}
