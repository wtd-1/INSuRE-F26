#include "maliciousveins/maliciousRSU.h"
#include "maliciousveins/ApplicationLayerTestMessage_m.h"

using namespace veins;
using namespace maliciousveins;

Define_Module(maliciousveins::maliciousRSU);

void maliciousRSU::onWSA(veins::DemoServiceAdvertisment* wsa)
{
    // if this RSU receives a WSA for service 42, it will tune to the chan
    if (wsa->getPsid() == 42) {
        mac->changeServiceChannel(static_cast<Channel>(wsa->getTargetChannel()));
    }
}

void maliciousRSU::onWSM(veins::BaseFrame1609_4* frame)
{
    ApplicationLayerTestMessage* wsm = check_and_cast<ApplicationLayerTestMessage*>(frame);

    // this rsu repeats the received traffic update in 2 seconds plus some random delay
    sendDelayedDown(wsm->dup(), 2 + uniform(0.01, 0.2));
}

void maliciousRSU::onBSM(veins::DemoSafetyMessage* bsm)
{
	sendDown(bsm->dup());
}
