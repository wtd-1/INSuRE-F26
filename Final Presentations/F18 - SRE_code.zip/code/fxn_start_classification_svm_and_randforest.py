import os
import json
import csv
import random
import numpy as numpy
import scipy
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix
from scipy.sparse import csr_matrix
from scikits.learn.svm.sparse import SVC


def oneHotEncoding(digit, debugFlag=False):
    #
    #   digit is a decimal number in the range of 0 to 255
    #

    n = 256

    oneHot = numpy.zeros(n)
    oneHot[digit] = 1
    return oneHot


def loadData(startDir, endDir, debugFlag=False):
    #
    #   returns dictionary, data_ten_dirs, of numpy arrays of the form
    #
    #       [ [oneHotVector_x1, label_y1], ..., [oneHotVector_xk, label_yk] ]
    #
    #   where each dictionary entry consists of all binary files in the directory
    #

    data_ten_dirs = {}
    for index in range(startDir, endDir):
        data_ten_dirs[str(index)] = []

    for index in range(startDir, endDir):
        parentDir = os.path.join('training_data_small', str(index))
        files = os.listdir(parentDir)
        for name in files:
            binary_name = os.path.join(parentDir, name)
            with open(binary_name, 'r') as f_datafile:
                rdr = csv.reader(f_datafile, delimiter='\n')
                for row in rdr:
                    if len(row) == 0:
                        continue
                    pair = row[0].split(',')
                    x = csr_matrix( oneHotEncoding(int(pair[0], 16)) )
                    label = int(pair[1])
                    data_ten_dirs[str(index)].append([x, label])
        data_ten_dirs[str(index)] = numpy.array(data_ten_dirs[str(index)]) 
    return data_ten_dirs


def svmClassification(train, validation, test, test_dir_name, is_hypertuning, debugFlag=False):
    #
    # training_data
    # validation_data
    # test_data
    # cur_fold
    # hyperparam_tuning
    # debugFlag
    #

    print('\nSVM Classification for TestDir = {}'.format(test_dir_name))

    all_data = train

    # trainingdata [ [vector55, 1], [vector89, 0], ...]
    #attributes = numpy.array([data_point[0] for data_point in all_data])
    #train_classes = numpy.array([data_point[1] for data_point in all_data])
    attributes, train_classes = train

    # testdata [ [vector55, 1], [vector89, 0], ...]
    #test_attributes = numpy.array([data_point[0] for data_point in test])
    #test_classes = numpy.array([data_point[1] for data_point in test])
    test_attributes, test_classes = test

    num_test_examples = len(test_classes)

    if is_hypertuning:
        # Test g from 10e-08 to 10e8 to see which values give the best accuracy. C from 1 to 100.
        gamma = 10e-8
        max_accuracy = -1
        best_gamma = -1
        best_C = -1

        '''
        #TODO: implement hyperparameter tuning

        # validationdata [ [vector55, 1], [vector89, 0], ...]
        validation_attributes = numpy.array([data_point[0] for data_point in validation])
        validation_classes = numpy.array([data_point[1] for data_point in validation])

        while gamma <= 10e8:
            for cost in range(1, 101):
                # gamma is the learning rate. cost is the penalty term for a wrong prediction
                clf = svm.SVC(g=gamma, C=cost, kernel='rbf')
                scores = cross_val_score(clf, attributes, train_classes, cv=5)
                accuracy = sum(scores) / len(scores)
                if accuracy > max_accuracy:
                    max_accuracy = accuracy
                    best_gamma = gamma
                    best_C = cost
        '''
    else:

        clf = SVC(gamma=10e-8)  # gamma='scale')
        clf.fit(attributes, train_classes)
        predictions = clf.predict(test_attributes)  # , test_classes )
        confusion_mat = confusion_matrix(test_classes, predictions, [0, 1])
        confusion_arr = confusion_mat.ravel()

        if debugFlag:
            assert sum(confusion_arr) == num_test_examples

            true_0, false_1, false_0, true_1 = confusion_arr
            print('svm debugging: predictions = {}'.format(predictions))
            print('svm debugging: test_classes = {}'.format(test_classes))

            print('svm debugging: [true_0, false_1, false_0, true_1] = {}'.format(
                [true_0, false_1, false_0, true_1]))
            print('svm debugging: accuracy = {}'.format(
                float(true_0 + true_1) / num_test_examples))

        return confusion_arr


def randomForestClassification(train, validation, test, test_dir_name, is_hypertuning, debugFlag=False):
    #
    # training_data
    # validation_data
    # test_data
    # cur_fold
    # ?????????
    # ?????????
    #
    print('\nRandom Forest Classification for TestDir = {}'.format(test_dir_name))

    all_data = train

    attributes, train_classes = train

    test_attributes, test_classes = test

    num_test_examples = len(test_classes)

    if is_hypertuning:
        # Test hyperparameters to see which values give the best accuracy. 
        #      n_trees from 1 to 1000
        #      max_depth from 2 to 50.
        num_trees = 1
        max_tree_depth = 2
        max_accuracy = -1
        best_n_trees = -1
        best_max_depth = -1

        '''
        #TODO: implement hyperparameter tuning

        # validationdata [ [vector55, 1], [vector89, 0], ...]
        #validation_attributes = numpy.array([data_point[0] for data_point in validation])
        #validation_classes = numpy.array([data_point[1] for data_point in validation])

        validat_attributes, validat_classes = validation

        while num_trees <= 1000:
            for max_tree_depth in range(2, 51):

                # n_trees is the number of trees in the forest. max_depth is the depth of trees in the forest
                clf = RandomForestClassifier(n_estimators=num_trees, max_depth=max_tree_depth )#, random_state=0)

                #scores = cross_val_score(clf, attributes, train_classes, cv=5)
                #accuracy = sum(scores) / len(scores)

                clf.fit( attributes, train_classes)
                predictions = clf.predict( validat_attributes)
                confusion_mat = confusion_matrix( validat_classes, predictions, [0, 1])
                confusion_arr = confusion_mat.ravel()
                
                if accuracy > max_accuracy:
                    max_accuracy = accuracy
                    best_n_trees = num_trees
                    best_max_depth = max_tree_depth
        '''
    else:

        num_trees = 10
        max_tree_depth = 50

        clf = RandomForestClassifier(n_estimators= num_trees, max_depth=max_tree_depth )#, random_state=0)

        clf.fit( attributes, train_classes)
        predictions = clf.predict( test_attributes)
        confusion_mat = confusion_matrix( test_classes, predictions, [0, 1])
        confusion_arr = confusion_mat.ravel()


        if debugFlag:
            assert sum(confusion_arr) == num_test_examples

            true_0, false_1, false_0, true_1 = confusion_arr
            print('random forest debugging: predictions = {}'.format(predictions))
            print('random forest debugging: test_classes = {}'.format(test_classes))

            print('random forest debugging: [true_0, false_1, false_0, true_1] = {}'.format(
                [true_0, false_1, false_0, true_1]))
            print('random forest debugging: accuracy = {}'.format(
                float(true_0 + true_1) / num_test_examples))

        return confusion_arr




if __name__ == '__main__':

    debugFlag = True
    startDir = 1
    endDir = 2  # 11
    hyperparam_tuning = False

    # shorten onehotencoding fxn name
    def one(x): return oneHotEncoding(x)

    if debugFlag:
        # debug data
        dbg1 = [['55', 1], ['89', 0], ['e5', 0]]
        dbg2 = [['83', 1], ['ec', 0], ['1c', 0]]
        dbg3 = [['55', 1], ['8b', 0], ['45', 0], ['a8', 0]]

        startDir = 1
        endDir = 4

        #x = oneHotEncoding( int( pair[0], 16) )
        #label = int( pair[1] )
        #
        data = {'1': numpy.array( [[csr_matrix( one(int(elmt[0], 16)) ), int(elmt[1])] for elmt in dbg1] ),
                '2': numpy.array( [[csr_matrix( one(int(elmt[0], 16)) ), int(elmt[1])] for elmt in dbg2] ),
                '3': numpy.array( [[csr_matrix( one(int(elmt[0], 16)) ), int(elmt[1])] for elmt in dbg3] ),
                }
    else:
        data = loadData(startDir, endDir)

    train_data = []
    validation_data = []  # left empty if hyperparam_tuning var is False
    test_data = []

    # perform 10-fold crossvalidation
    for test_dir_name in [data.keys()[0]]:
        #test_data = data[test_dir_name] #[ [csr matrix, label], [csr matrix, label], ...]
        test_tup = tuple( [ elem[0] for elem in data[test_dir_name] ] )
        test_data = scipy.sparse.vstack( test_tup, format='csr' )
        test_labels = [elem[1] for elem in data[test_dir_name] ]
        num_test_examples = len(test_labels)
        remaining_dirs = [str(i) for i in range(
            startDir, endDir) if not (i == int(test_dir_name))]
        if hyperparam_tuning:
            # randomly choose a data_dir for validation from remaining data_dirs
            validation_dir = remaining_dirs[int(
                random.random() * len(remaining_dirs))]
            validation_data = data[validation_dir] #csr matrix
            remaining_dirs.remove(validation_dir)

        # concatenate the rest of dir data into single numpy matrix
        data_arr = []
        label_arr = []
        for rem_dir in remaining_dirs:
            cur_data = data[ rem_dir ]
            for elem in cur_data:
                data_arr.append( elem[0] )
                label_arr.append( elem[1] )
        data_tup = tuple( data_arr )

        #combine all remaining data directories to make training dataset
        #training_data = numpy.concatenate(data_tup, axis=0)
        training_data = scipy.sparse.vstack( data_tup, format='csr' ) 

        
        # svm classifier experiment
        #
        confus_arr = svmClassification( [training_data, label_arr] , validation_data, [test_data, test_labels], test_dir_name, hyperparam_tuning, debugFlag)
        true_0, false_1, false_0, true_1 = confus_arr
        print('svm debugging: [true_0, false_1, false_0, true_1] = {}'.format(
            [true_0, false_1, false_0, true_1]))
        print('svm debugging: accuracy = {}'.format(
            float(true_0 + true_1) / num_test_examples))
        

        # randomforest classifier experiment
        #
        confus_arr = randomForestClassification( [training_data, label_arr] , validation_data, [test_data, test_labels], test_dir_name, hyperparam_tuning, debugFlag)
        true_0, false_1, false_0, true_1 = confus_arr
        print('random forest debugging: [true_0, false_1, false_0, true_1] = {}'.format(
            [true_0, false_1, false_0, true_1]))
        print('random forest debugging: accuracy = {}'.format(
            float(true_0 + true_1) / num_test_examples))

       