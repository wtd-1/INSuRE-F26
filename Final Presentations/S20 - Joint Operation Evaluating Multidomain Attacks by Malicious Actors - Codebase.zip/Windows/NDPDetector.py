import time
import logging
import os
from pathlib import Path
from SMWinservice import SMWinservice
from scapy.all import *

#fe80::2ded:4890:2294:3a0d


class NDPDetector(SMWinservice):
	_svc_name_ = "NDP Detector"
	_svc_display_name_ = "NDP Detector"
	_svc_description_ = "Detects and logs all incoming NDP Packets"
	
	def packetDetected(self,pkt):
		logging.info("NDP packet detected at "+time.ctime()+": \n"+str(pkt)+"\n")
		
	def checkLogDirExists(self, lp):
		if not os.path.exists(lp):
			os.mkdir(lp)
	
	def start(self):
		self.should_stop_sniff=False
		logpath=".\\logs\\"
		self.checkLogDirExists(logpath)
		t = int(round(time.time()*1000))
		fn="Session"+str(t)+".txt"
		logging.basicConfig(filename=logpath+fn,level=logging.DEBUG)
		
		
	def stop(self):
		self.should_stop_sniff = True

	def main(self):
		sniff(lfilter = lambda x: x.haslayer(IPv6) and any(y in x[Ether][IPv6] for y in [ICMPv6ND_NA, ICMPv6ND_NS, ICMPv6ND_RA, ICMPv6ND_RS, ICMPv6ND_Redirect]), store = 0, count=0, prn = self.packetDetected, stop_filter=self.should_stop_sniff)
		
if __name__ == '__main__':
	NDPDetector.parse_command_line()