import time
import logging
import os
from pathlib import Path
from SMWinservice import SMWinservice
from scapy.all import *

#fe80::2ded:4890:2294:3a0d


class NDPDetector(SMWinservice):
	_svc_name_ = "NDP Anomaly"
	_svc_display_name_ = "NDP Anomaly"
	_svc_description_ = "Detects and logs anomalous NDP Packets"
	
	
	def packetDetected(self,pkt):
		
		if pkt[Ether].src in self.macs and self.macs[pkt[Ether].src] != pkt[Ether][IPv6].src:
			logging.info('Packet '+ self.pkt_count)
			self.pkt_count=self.pkt_count+1
			logging.warning('ANOMALY DETECTED')
			logging.warning(pkt[Ether].src+' is trying to use '+pkt[Ether].src+' as IPv6 instead of previously recorded '+self.macs[pkt[Ether].src])
			logging.info("Mappings:", self.macs)
		else:
			macs[pkt[Ether].src] = pkt[Ether][IPv6].src
		
	def checkLogDirExists(self, lp):
		if not os.path.exists(lp):
			os.mkdir(lp)
	
	def start(self):
		self.macs = dict()
		self.should_stop_sniff=False
		logpath=".\\logs\\"
		self.checkLogDirExists(logpath)
		self.pkt_count=0
		t = int(round(time.time()*1000))
		fn="Session"+str(t)+".txt"
		logging.basicConfig(filename=logpath+fn,level=logging.DEBUG)
		
		logging.info("Mapping of MAC Addresses at Initialization:", self.macs)
		
		
		
	def stop(self):
		self.should_stop_sniff = True

	def main(self):
		sniff(lfilter = lambda x: x.haslayer(IPv6) and any(y in x[Ether][IPv6] for y in [ICMPv6ND_NA, ICMPv6ND_NS, ICMPv6ND_RA, ICMPv6ND_RS, ICMPv6ND_Redirect]), store = 0, count=1, timeout=30, prn = self.packetDetected, stop_filter=self.should_stop_sniff)
		
if __name__ == '__main__':
	NDPDetector.parse_command_line()