Execution instructions for windows:
The windows version of the NDP detector runs as a windows service. 

To install a service run the command 
	$ python [Windows Service].py install

After making changes to a windows service run
	$ python [Windows Service].py update
	
Running the service:
	1: Bring up the run dialog (win+r)
	2: Type services.msc
	3: Find the name of the service installed above 
		(If this name isn't readily apparently, it can be found in the _svc_name_ variable in the .py file you installed above)
	4: Start the service

Troubleshooting:
For any future collaborators of this project, should the service start and immediately stop, an error was thrown from python.
These errors are hard to find because there are no dialogs/stack traces. I recommend creating a non-windows service script for testing purposes then porting that to the windows service version or finding a way to log the errors.
