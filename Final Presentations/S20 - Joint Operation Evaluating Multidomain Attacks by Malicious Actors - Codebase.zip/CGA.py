# 04/30/20
# https://tools.ietf.org/html/rfc3972
# check out cga spec sheet to see steps for generating and verifying CGA 
import argparse
import random
import hashlib
#from scapy.layers.inet6 import *
from Crypto.PublicKey.RSA import construct
import re 
import unittest
from asn1crypto.x509 import Certificate
import sys

class CGA:
    
    def __init__(self,prefix,sec,cert=None,optional_parameters=1):
       self.prefix = prefix
       self.sec = sec
       self.optional_parameters = optional_parameters
       self.cert = 1
       self.public_key = construct((n, e))
       #print (self.public_key)

    def generate_CGA(self):
 
        #*step 1
        modifier = random.getrandbits(128)
        #*step 2 and three 
        while(True):
            concat = str(modifier) + 9 * '00000000' + str(self.public_key) #+ str(self.optional_parameters)
            #hash convert to binary 
            binhash = hashConvertBinary(concat)
            leftmostbits =  binhash [0:112]
            #*step 3
            val2 = (112 - (16*self.sec))
            hash2 = leftmostbits [0:val2]
            #print (hash2[0:16])
            if(int(hash2) == 0 or self.sec == 0):
                break
            modifier = modifier + 1
        #*step 4 
        collision_count = 0
        
        while(True):
            #*Step 5 : concat and hash 
            concat =str(modifier) + str(self.prefix) + str(collision_count) + str(self.public_key) #+ str(self.optional_parameters)
            #hash and convert to binary           
            binhash =hashConvertBinary(concat)
            # 64 leftmost bits  
            leftmostbits =  binhash [0:64]
            hash1 = leftmostbits
            #* Step 6 
            secBit=  bin (self.sec)[2:]
            #make sure secBit is 3 bits 
            if(len(secBit) == 1): 
                secBit= '00' + secBit
            elif(len(secBit) == 2): 
                secBit= '0' + secBit
            #adding secBit
            intID= secBit + hash1[3:]
            intID= intID[0:5] + "00" + intID[7:]
             
            #*Step 7
            #convert binary id to hex
            intIDhex= concatHex(intID)                       
            concact_CGA = str(self.prefix) + intIDhex

            if(dubplicate(concact_CGA)):

               collision_count = collision_count+1
               if  (collision_count==2):
                   print("Error CGA address collision  ")
                   break
                #label2()
            else: 
                break
        
        # Modifier | Subnet Prefix | collision count | public key | optional param
        cga_Param = [modifier, self.prefix, collision_count, self.public_key, self.optional_parameters]
        #print (concact_CGA)
        return (concact_CGA, cga_Param)


    def verification_CGA(self, ipv6_Address, cga_param):
        modifier =cga_param[0]
        prefix= cga_param[1]
        collision_count = cga_param[2]
        public_key= cga_param[3]
        opt_param= cga_param[4]

        #ipv6 without prefix
        ipv6= ipv6_Address.replace(":","") [13:]
        intipv6= int(ipv6, 16)
        binipv6 =bin (intipv6)[2:]
        binipv6 = paddingBits(binipv6)
        x= len(binipv6)

        #*step1 check the collision valid range
        if( collision_count <0 and collision_count>2):
            print("fails collision count check verification")
            return
        #*step 2 check subnet prefix 
        ipv6_A_prefix= ipv6_Address [0:17]
        if ( prefix != ipv6_A_prefix ):
            print("fails subnet prefix verification ")
            return
        #*Step 3 Get hash1
        concat= str(modifier) + str(prefix) + str(collision_count) + str(public_key) #+ opt_param
        binhash =hashConvertBinary(concat)
        hash1 =  binhash [0:64]
        #* Step 4: compare hash1 with the interface identifier
        intID=  binipv6[3:5] + '00' + binipv6[7:]
        hash1U=  hash1[3:5] + '00' + hash1[7:]
        if(hash1U != intID):
            print("verification fails with interface indentifier")
            return 
        #* Step 5 read the sec parameter from the three leftmost bits 
        sec= binipv6[0:3]
        #* step 6 create hash2 
        concat = str(modifier) + 9 * '00000000' + str(public_key)  # + opt_param
        binhash =hashConvertBinary(concat)
        hash2 =  binhash [0:112]
        #*step 7
        #* compare the 16 sec lefmost bits of hash2 
        secInt= (int(sec, 2))
        secbits = 16* secInt
        hash2_Check=0
        if (secInt !=0):
            hash2_Check= hash2[0:secbits]
        if( hash2_Check !=0 or secInt !=0):
            print ("fails at hash2 verification")
            return
        print ("Verified ")
#check for duplicate address
#? Not done yet
def dubplicate( concat_CGA):
    return False
#convert hash to binary 6
def hashConvertBinary(concat):
    sha1hash = hashlib.sha1(bytes(concat, 'utf-8'))
    digest = sha1hash.hexdigest()
    inthash= int(digest, 16)
    binhash =bin (inthash)[2:]
    return binhash

# assemble binary into hash
def concatHex(binary):
    y =hex(int(binary, 2))[2:]
    #print(y)
    z = len(y)
    i=0
    while (True) :
        if (z<=4):
            while(True):
                if(z==4 or z==0):
                    break
                z=z+1
                y= "0"+y
            break
        z=z-4
        y = y[0:z] +":" + y[z:]
    #print(y)
    return y

def paddingBits(binary):
    while(len(binary)<64):
        binary='0'+binary
    return binary

def parse_key(filepath):       
    with open(filepath,"rb") as file:
        cert = Certificate.load(file.read())
    try:
        n = cert.public_key.native["public_key"]["modulus"]
        e = cert.public_key.native["public_key"]["public_exponent"]
    except:
        e = sys.exc_info()[0]
        #print(e)
        exit(1);
    return (e,n)

def check_prefix(prefix):
    pattern_obj = re.compile(r"(([0-9a-fA-F]{1,4}:)([0-9a-fA-F]{1,4}:)([0-9a-fA-F]{1,4}:)([0-9a-fA-F]{1,4}):)")
    if pattern_obj.match(prefix) is None:
        argparse.ArgumentError("Bad IPv6 prefix")
    else:
        return prefix
    
    
if __name__ == '__main__':
    #arguments:
    #64bit IPv6 prefix
    #DER encoded public key
    #1 byte
    parser = argparse.ArgumentParser(description='Cryptographically generate IPv6 addresses')
    parser.add_argument('--prefix',dest='prefix',required=True,help='64-bit prefix of IPv6 address',type=check_prefix)
    parser.add_argument('--sec',dest='sec',help='Security byte',type=int,choices=range(0,8),required=True)
    parser.add_argument('--cert_path',dest='cert_path',help='Path to DER encoded certificate',type=str,required=True)
    args = parser.parse_args( )
    (e,n) = parse_key(args.cert_path)
    #print("E " , e)
    #print("n" , n)
    cgaClass = CGA(args.prefix,args.sec)
    cga, cgaParam = cgaClass.generate_CGA();
    print ("Created CGA: "+cga)
    #print (cgaParam)
    cgaClass.verification_CGA(cga , cgaParam)
