#!/usr/bin/env python

#Change this to whatever network interface you want to monitor on
IFACE = 'wlp2s0'

from scapy.all import *
import os
macs = dict()

#Basic initialization function
def _init():
    print('Hello from the NDP monitor')

    #Pre-populate cache from output of ip -6 neighbour command, which outputs the current IPv6 mapping table
    neighbours = os.popen('ip -6 neighbour').read().split('\n')

    #Filter out invalid or failed mappings using STALE and REACHABLE state values, different values may work better
    live_neighbours = [i for i in neighbours if 'STALE' in i or 'REACHABLE' in i]

    #Create cache mapping for each live neighbour
    for entry in live_neighbours:
        vals = entry.split(' ')
        
        #Create entry in cached mapping
        macs[vals[4]] = vals[0]

    print('Current mappings at initialization', macs)
    mon_callback.cnt = 0

#Callback function for when an NDP packet is detected
def mon_callback(pkt):

    #If an NDP packet is detected that has the same source MAC address but a different IPv6 address, can assume that the source machine is spoofing or doing something suspicious
    if pkt[Ether].src in macs and macs[pkt[Ether].src] != pkt[Ether][IPv6].src:
        print('Packet %d - ANOMALY DETECTED' % mon_callback.cnt)
        print('{0} is trying to use {1} as IPv6 instead of previously recorded {2}'.format(pkt[Ether].src, pkt[Ether][IPv6].src ,macs[pkt[Ether].src]))
        print('Current mappings', macs)

    #Otherwise, add mapping to the cache
    else:
        macs[pkt[Ether].src] = pkt[Ether][IPv6].src

    mon_callback.cnt += 1
    
def main():
    _init()

    #Sniff with callback, uses lfilter to only callback on ICMPv6 packets with the 5 main NDP messages
    sniff(iface=IFACE, lfilter = lambda x: x.haslayer(IPv6) and any(y in x[Ether][IPv6] for y in [ICMPv6ND_NA, ICMPv6ND_NS, ICMPv6ND_RA, ICMPv6ND_RS, ICMPv6ND_Redirect]), store = 0, prn = mon_callback)

if __name__ == '__main__':
    main()