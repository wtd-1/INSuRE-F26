Description
	PEFeatExt.py takes as input a Windows executable and outputs a list of extracted features.
	
	Extracted Features
	
		Searching strings
			Programming language (Go, Java, Python) 
			Python-specific:
				Padding (“PADDINGXX”) present
				If exe created from pyinstaller, use pyinstxtractor to extract:
					Pyinstaller version
					Python version
					Length of package
					Number of files in pyinstaller archive
					Possible entry points
			Java-specific:
				Classes:
					Classes in source code package 
						Identified by ending in .classPK
					Imported packages/classes/functions
						Identified by java/*
			Go-specific:
				Function calls (from main):
					Identified by main.*
				Imported libraries/packages/functions:
					Identified by vendor/golang.org/x/*
					Identified by go.itab.*


		Pefile
			Timestamp for executable was created
			Architecture PE is supposed to be run on
			Interpreted as a 32-bit or 64-bit binary
			Warnings while parsing PE to determine anomalies (i.e. obfuscation)
			Imported DLLs and their corresponding imported functions
			Packers that match PEiD signatures (may not work)

		Peframe
			Antidebug - Any DLLs or API function calls specific to anti-debugging
			Antivm - Any DLLs or API function calls specific to anti-virtual machines
			Packers
			Crypto
			Files and file types in the strings
			URLs in the strings
			IP addresses in the strings
			Fuzzing in the strings
			Antivirus
			Metadata:
				Comments
				Company Name
				File Description
				File Version
				Internal Name
				Legal Copyright
				Legal Trademarks
				Original Filename
				Product Name
				Product Version

		Python-magic
			File type


Run
	python3 PEFeatExt.py filepathofexe


Dependencies
	python3
		default on kali
	pefile
		default on kali
	peframe
		https://github.com/guelfoweb/peframe
	python-magic
		default on kali
		
File structure:
	Project Folder\
		PEFeatExt.py
		pyinstxtractor\
			pyinstxtractor.py
			__init__.py
		peframe\
			peframe.py
			peframecli.py
			__init__.py
			modules\
			signatures\
		signatures\
			stringsmatch.json
			userdb.txt
			yara_plugins\
			peid_sigs\
				UserDB.TXT
		
	