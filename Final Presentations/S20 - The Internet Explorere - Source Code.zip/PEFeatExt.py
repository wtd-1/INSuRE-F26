# File: PEFeatExt.py
# Authors: Anmol Agarwal, Gina Fossati, Jennifer Ward
# Last Modified: 4/27/2020

import sys
import os.path
import re
import pefile
import peutils
import magic
import json
import hashlib
from peframe.modules import directories
from peframe.modules import meta
from peframe.modules import features
from peframe.modules import fileurl
from peframe.modules import virustotal
from datetime import datetime
from pyinstxtractor import pyinstxtractor as pyin


# Determines if file passed is a Portable Executable (PE)
def ispe(filename):
    if re.match(r'^PE[0-9]{2}|^MS-DOS', getFileType(filename)):
        return True
    return False


# Get path to file
def path_to_file(filename, folder):
    _ROOT = os.path.abspath(os.path.dirname(__file__))
    return os.path.join(_ROOT, folder, filename)


# Load configuration file
def load_config(config_file):
    with open(config_file) as conf:
        data = json.load(conf)
    return data

# Compute hash for file
def getHash(filename):
    fh = open(filename, 'rb')
    m = hashlib.md5()

    while True:
        data = fh.read(8192)
        if not data:
            break
        m.update(data)

    return m.hexdigest()

# Check strings in executable for any indications of programming language - specifically, Go, Java, or Python.
def checkStrings(fileStrings):
    # If language is Go
    if re.search("golang", fileStrings):
        return "Go"
    # If language is Java
    elif re.search("[Jj]ava", fileStrings):
        return "Java"
    # If language is Python
    elif re.search("[Pp]ython", fileStrings):
        return "Python"
    # If none of the above languages are identifiable in the executable strings
    else:
        print("Program language not recognized. This program currently checks for Java, Python, and Go executables.")
        return "Unknown"


# Run the strings command and grep for PADDINGXX
def getPadding(fileStrings):
    #os.system('strings '+filename+'|grep "PADDINGXX"')
    if re.search("PADDINGXX", fileStrings):
        return "True"
    else:
        return "False"

# Determine if exe created with pyinstaller & perform analysis
def depyinstall(file):
    # Create archive
    arch = pyin.PyInstArchive(file)
    # If archive open / exists
    if arch.open():
        print("Pyinstaller:")
        if arch.checkFile():
            if arch.getCArchiveInfo():
                arch.parseTOC()
                arch.printData()
                arch.close()


# Retrieve any classes used in the Java source code
def getJavaClasses(fileStrings):
    classes = re.findall(r"[\w|\$|/]+\.classPK", fileStrings, re.MULTILINE)
    print("Classes:")
    for classname in classes:
        # Classes in the program are of the format filename/classname.classPK
        if re.search("classPK", classname):
            endIndex = classname.index("classPK") - 1
            print("\t", classname[:endIndex])
        # Find all strings in exe that start with java/

    classes = re.findall(r"java/[\w|\$|/]+", fileStrings, re.MULTILINE)
    printed = []
    for classname in classes:
        if classname not in printed:
            # Only print if import has not already been printed
            print("\t", classname)
            printed.append(classname)

# Retrieve any function calls in Go
def getGoFunctionCalls(fileStrings):
    calls = re.findall("main\.[\w|\$|/]+", fileStrings, re.MULTILINE)
    print("Functions calls (from main):")
    printed = []
    for call in calls:
        if call not in printed:
            print("\t", call)
            printed.append(call)

# Retrieve imported libraries/packages in Go
def getGoImports(fileStrings):
    libs = re.findall("vendor/golang.org/x/[\w|\$|/]+", fileStrings, re.MULTILINE)
    print("Go Imports:")
    printed = ['']
    for lib in libs:
        startIndex = len("vendor/golang.org/x/") - 1
        lib = lib[startIndex:].split('/')[1:]
        lib_print = ''
        for i in range(len(lib) - 2):
            lib_print += "/" + lib[i]
        if lib_print[1:] not in printed:
            print("\t", lib_print[1:])
            printed.append(lib_print[1:])

    libs = re.findall("go.itab.\*[\w|\$|\.]+", fileStrings, re.MULTILINE)
    for lib in libs:
        startIndex = len("go.itab.*")
        lib = lib[startIndex:]
        if lib not in printed:
            print("\t", lib)
            printed.append(lib)

# Get timestamp of PE file
def getTimeStamp(pe):
    return datetime.utcfromtimestamp(pe.FILE_HEADER.TimeDateStamp).strftime('%Y-%m-%d %H:%M:%S')


# Get file type information
def getFileType(filename):
    return magic.from_file(filename)


# Check what architecture this binary is supposed to run on
# 0x014C == x86 and 0x8664 == x86-x64 binary
def getMachine(pe):
    if hex(pe.FILE_HEADER.Machine) == '0x014c':
        return "32-bit (x86)"
    else:
        return "64-bit (x86-x64)"


# Determine if binary will be interpreted as a 32-bit or 64-bit binary
# 0x10B == 32bit, 0x20B == 64bit
def getMagic(pe):
    if hex(pe.OPTIONAL_HEADER.Magic) == '0x10b':
        return "32-bit binary"
    elif hex(pe.OPTIONAL_HEADER.Magic) == '0x20b':
        return "64-bit binary"


# Get any files included in the strings of the executable
def getFiles(strs):
    return strs["file"]


# Get any URLs included in the strings of the executable
def getURLs(strs):
    return strs["url"]


# Get any ip addresses included in the strings of the executable
def getIPs(strs):
    return strs["ip"]


# Get any fuzzing included in the strings of the executable
def getFuzzing(strs):
    return strs["fuzzing"]


# Get any DLLs or API functions associated with crypto
def getCrypto(feats):
    return feats["crypto"]


# Get any DLLs or API functions associated with antidebugging
def getAntidebug(feats):
    return feats["antidbg"]


# Get any DLLs or API functions associated with anti virtual machines
def getAntivms(feats):
    return feats["antivm"]


# Identify any packers
def getPackers(feats):
    return feats["packer"]


# Determine directories in the executable
def getDirectories(pe):
    # Get the directories in the PE
    dirs = directories.get(pe)

    # Get directories list
    return list([key for key, value in dirs.items() if value])


# Determine metadata in PE
def getMeta(pe):
    return meta.get(pe)

# Determine any antivirus in the executable
def getAntivirus(filename):
    vt = virustotal.get_result(load_config(path_to_file('config-peframe.json', 'config'))['virustotal'], getHash(filename), full=True)
    print("Antivirus:")
    if vt['response_code'] == 200:
        print(json.dumps(vt['results']['scans'], sort_keys=True, indent=4))

# Determine any warnings encountered when parsing the PE file.
# This may lead to observations of anomalies in the executable, such as obfuscation.
def getWarnings(pe):
    print("Warnings: ")
    warnings = pe.get_warnings()
    for warn in range(len(warnings)):
        print(warnings[warn])


# Determine which DLLs and corresponding functions are imported by this executable
def getImports(pe):
    print("Imports: ")
    # Imported DLLs
    for library in pe.DIRECTORY_ENTRY_IMPORT:
        print("\tLibrary: " + library.dll.decode("utf-8"))
        print("\t\tFunctions imported from " + library.dll.decode("utf-8") + ":")
        # Functions imported from the library
        for function in library.imports:
            print("\t\t\t" + function.name.decode("utf-8"))


# Use PEiD signatures
def getPEIDMatches(pe):
    # Path to signature database
    # Recommendation is to keep signatures in 'signatures/peid_sigs' folder in current directory
    dbdir = os.path.join(os.getcwd(), "signatures/peid_sigs")

    # Check that directory exists
    if os.path.isdir(dbdir):
        print("PEiD Signature Matches: ")
        # Iterate over all signature files (txt) in this directory
        for sigFile in os.listdir(dbdir):
            if sigFile.endswith(".txt"):
                # Signature file
                sigFile = os.path.join(dbdir, sigFile)
                # Load database from a file in the local filesystem
                signatures = peutils.SignatureDatabase(sigFile)
                # Run PE instances through the DB in order to find matching packer signatures
                matches = signatures.match(pe, ep_only=True)
                # Print matches
                print(matches)
    else:
        print("PEiD signatures not in signatures/peid_sigs folder.")


def main():
    # Get filepath/name of executable to examine
    filename = str(sys.argv[1])
    # Check if file exists
    if os.path.isfile(filename):

        # Check if file is a Windows executable
        if not ispe(filename):
            print("Error! File is not a Windows executable!")
            raise SystemExit

        # All strings in executable
        fileStrings = open(filename, "rb").read().decode('ISO-8859-1')

        # Load executable
        pe = pefile.PE(filename)

        # Extract certain features from pe
        feats = features.get_result(pe, filename)

        # Extract strings from pe for specific string matching purposes
        strs = fileurl.get_result(filename, load_config(path_to_file('stringsmatch.json', 'signatures')))

        # NAME - Name of executable
        print("Filename: " + os.path.basename(filename))

        # PROGRAMMING LANGUAGE
        # Determine programming language used to write source code of executable (if possible)
        progLanguage = checkStrings(fileStrings)
        print("Programming Language: " + progLanguage)
        #getStringsLang(filename)

        # TIMESTAMP for the PE
        timestamp = getTimeStamp(pe)
        print("Timestamp: " + timestamp)

        # Python specific
        if progLanguage == "Python":
            # PADDING - check if there is padding (usually from the compiler)
            print("PADDINGXX: ", getPadding(fileStrings))
            # PYINSTXTRACTOR - check if exe made from pyinstaller & perform analysis
            depyinstall(filename)

        # Java specific
        if progLanguage == "Java":
            # CLASSES
            getJavaClasses(fileStrings)

        # Go specific
        if progLanguage == "Go":
            getGoFunctionCalls(fileStrings)
            getGoImports(fileStrings)

        # FILE TYPE of PE
        filetype = getFileType(filename)
        print("File Type: " + filetype)

        # MACHINE - header field
        machine = getMachine(pe)
        print("Machine: " + machine)

        # MAGIC - header field
        magic = getMagic(pe)
        print("Magic: " + magic)

        # METADATA
        metadata = getMeta(pe)
        print("Metadata:")
        for k, v in metadata.items():
            print("\t", k.ljust(20, ' '), v[0:63])

        # CRYPTO
        cryptos = getCrypto(feats)
        print("Crypto:")
        for item in cryptos:
            print("\t", item)

        # ANTIDEBUG
        antidebugs = getAntidebug(feats)
        print("Antidebug:")
        for item in antidebugs:
            print("\t", item)

        # ANTIVM
        antivms = getAntivms(feats)
        print("Antivm:")
        for item in antivms:
            print("\t", item)

        # PACKER
        packers = getPackers(feats)
        print("Packers:")
        for item in packers:
            print("\t", item)

        # FILES
        files = getFiles(strs)
        print("Files:")
        for k, v in files.items():
            print("\t", k.ljust(50, ' '), v)

        # URLS
        urls = getURLs(strs)
        print("URLs:")
        for item in urls:
            print("\t", item)

        # IP ADDRESSES
        ips = getIPs(strs)
        print("IPs:")
        for item in ips:
            print("\t", item)

        # FUZZING
        fuzzing = getFuzzing(strs)
        print("Fuzzing:")
        for k, v in fuzzing.items():
            print("\t", k)

        # ANTIVIRUS
        getAntivirus(filename)

        # IMPORTS - imported DLLs and functions
        # Function prints output
        getImports(pe)
        print()

        # PEID - PEiD signatures
        # Function prints output
        getPEIDMatches(pe)

        # WARNINGS - possible errors encountered while parsing the PE
        # Function prints output
        getWarnings(pe)
        print()

    else:
        print("Error! File does not exist on the machine.")
        raise SystemExit


if __name__ == "__main__":
    main()