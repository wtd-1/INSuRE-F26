(herald "5G EAP-TLS Protocol"
	(comment "5G-EAP-TLS Protocol using TLS ver 1.2")
	(reverse-nodes)
	(bound 20)
	(limit 100))

(defprotocol eap basic
	(defrole ue
		(vars (nonce_ue nonce_ue1 nonce_ue2 nonce_nw supi data) (ue nw ca name))
		(trace
			(send (enc supi nonce_ue (pubk nw)))										
			(recv "tls_start")															; recv "tls_start"
			(send (cat nonce_ue1 "methods_ue"))											; send the nonce_ue1 and "methods_ue"
			(recv (cat nonce_nw (enc nw (pubk nw) (privk ca)) "methods_nw"))			; cert_nw = (enc nw (pubk nw) (privk ca))
			(send (cat (enc nonce_ue2 (pubk nw)) (enc ue (pubk ue) (privk ca)) 			; (rue2 enc w/pubk nw) + cert ue | cert_ue = (enc ue (pubk ue) (privk ca)) 
				(enc (hash "tls_start" nonce_ue1 "methods_ue" nonce_nw (enc nw (pubk nw) (privk ca))	; start of hash of handshake_ue
				"methods_nw")																			; end of hash of handshake_ue 
				(cat nonce_ue1 nonce_nw nonce_ue2))))									; session key: Kseaf
			(recv (enc (hash "tls_start" nonce_ue1 "methods_ue" nonce_nw (enc nw (pubk nw) (privk ca))	; start of hash of handshake_nw
				"methods_nw" (enc nonce_ue2 (pubk nw)) (enc ue (pubk ue) (privk ca))) 					; end of hash of handshake_nw
				(cat nonce_ue1 nonce_nw nonce_ue2)))									; session key: Kseaf
		)
		(non-orig (privk ca))
	)
	(defrole nw
		(vars (nonce_ue nonce_ue1 nonce_ue2 nonce_nw supi data) (nw ue ca name))
		(trace
			(recv (enc supi nonce_ue (pubk nw)))
			(send "tls_start")
			(recv (cat nonce_ue1 "methods_ue"))
			(send (cat nonce_nw (enc nw (pubk nw) (privk ca)) "methods_nw"))
			(recv (cat (enc nonce_ue2 (pubk nw)) (enc ue (pubk ue) (privk ca)) 			; (rue2 enc w/pubk nw) + cert ue | cert_ue = (enc ue (pubk ue) (privk ca)) 
				(enc (hash "tls_start" nonce_ue1 "methods_ue" nonce_nw (enc nw (pubk nw) (privk ca))	; start of hash of handshake_ue
				"methods_nw")																			; end of hash of handshake_ue 
				(cat nonce_ue1 nonce_nw nonce_ue2))))									; session key: Kseaf
			(send (enc (hash "tls_start" nonce_ue1 "methods_ue" nonce_nw (enc nw (pubk nw) (privk ca))	; start of hash of handshake_nw
				"methods_nw" (enc nonce_ue2 (pubk nw)) (enc ue (pubk ue) (privk ca))) 					; end of hash of handshake_nw
				(cat nonce_ue1 nonce_nw nonce_ue2)))									; session key: Kseaf
		)
		(non-orig (privk ca))
	)
)

;;; UE point of view.
(defskeleton eap
	(vars (nonce_ue nonce_ue1 nonce_ue2 nonce_nw supi data) (ue nw ca name))
	(defstrandmax ue 
		(nonce_ue nonce_ue) (nonce_ue1 nonce_ue1) (nonce_ue2 nonce_ue2) 
		(nonce_nw nonce_nw) (supi supi) (ue ue) (nw nw) (ca ca)
	)
	(uniq-orig nonce_ue)
	(uniq-orig nonce_ue1)
	(uniq-orig nonce_ue2)
	(non-orig (privk ue))
	(non-orig (privk nw))
)

;;; NW point of view.
(defskeleton eap
	(vars (nonce_ue nonce_ue1 nonce_ue2 nonce_nw supi data) (nw ue ca name))
	(defstrandmax nw 
		(nonce_ue nonce_ue) (nonce_ue1 nonce_ue1) (nonce_ue2 nonce_ue2) 
		(nonce_nw nonce_nw) (supi supi)(nw nw) (ue ue) (ca ca)
	)
	(non-orig (privk nw))
	(non-orig (privk ue))
	(uniq-orig nonce_nw)
)
